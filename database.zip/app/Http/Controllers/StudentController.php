<?php

namespace App\Http\Controllers;
use App\Models\Admin;

use Illuminate\Http\Request;
use App\Models\Student;
use Psy\TabCompletion\Matcher\FunctionsMatcher;

class StudentController extends Controller
{
    public function index(){
    
        $students = Student::all();
        return view('students.index', ['students' => $students]);
        
    }


    public function scount() {
        // Get total count of students
        $studentsCount = Student::count();
    
        // Count by roles
        $adminCount = Student::where('roles', 'LIKE', '%admin%')->count();
        $teacherCount = Student::where('roles', 'LIKE', '%teacher%')->count();
        $studentCount = Student::where('roles', 'LIKE', '%student%')->count();
        $kupalCount = Student::where('roles', 'LIKE', '%kupal%')->count();
    
        return view('dashboard', compact('studentsCount', 'adminCount', 'teacherCount', 'studentCount', 'kupalCount'));
    }

    public function create(){
        return view('students.create');
    }

    public function createe()
    {
        return view('students.createe');
    }


    public function store(Request $request){
        $data = $request->validate([
            'student_number' => 'required|numeric',
            'last_name' => 'required',
            'first_name' => 'required',
            'email' => 'required|email|unique:students,email',
            'year_level' => 'nullable',
            'course' => 'nullable',
            'roles' => 'required'
        ]);

        $newStudent = Student::create($data);

        return redirect(route('student.index'));
    }

    public function teacherstore(Request $request){
        $data = $request->validate([
            'student_number' => 'required|numeric',
            'last_name' => 'required',
            'first_name' => 'required',
            'email' => 'required|email|unique:students,email',
            'roles' => 'required'
        ]);
    
        $newStudent = Student::create($data); // Fixed here
    
        return redirect(route('student.index'));
    }


    public function edit(Student $student){
        return view('students.edit', ['student' => $student]);
    }

    public function update(Student $student, Request $request){
        $data = $request->validate([
            'student_number' => 'required|numeric',
            'last_name' => 'required',
            'first_name' => 'required',
            'email' => 'required|email|unique:students,email',
            'year_level' => 'nullable',
            'course' => 'nullable',
            'roles' => 'required'
        ]);

        $student->update($data);
        return redirect(route('student.index'))->with('success', 'Student Update Successfully');
    }

    public function destroy(Student $student){
        $student->delete();
        return redirect(route('student.index'))->with('success', 'Student Deleted Successfully');
    }

    public function indexCollege()
    {
        $students = Student::where('year_level', 'LIKE', '%College%')->get();
        return view('students.college', ['students' => $students]);
    }

    public function indexSeniorHigh()
    {
        $students = Student::where('year_level', 'LIKE', '%Senior High%')->get();
        return view('students.senior_high', ['students' => $students]);
    }

    public function teacher()
    {
        // Fetch only the students with the role 'teacher'
        $students = Student::where('roles', 'LIKE', '%teacher%')->get();

        return view('students.teacher', compact('students'));
    }
    

    public function editTeacher(Student $student)
    {
        return view('students.teacheredit', compact('student'));
    }

    public function teachersearch(Request $request)
{
    $search = trim($request->input('search'));

    $students = Student::where('roles', 'like', '%teacher%')
        ->when($search, function ($query) use ($search) {
            $query->where(function ($q) use ($search) {
                $q->where('student_number', 'like', "%{$search}%")
                ->orWhere('first_name', 'like', "%{$search}%")
                ->orWhere('last_name', 'like', "%{$search}%");

                if (str_contains($search, ' ')) {
                    $parts = explode(' ', $search, 2);
                    $firstName = $parts[0];
                    $lastName = $parts[1] ?? '';

                    $q->orWhere(function ($query) use ($firstName, $lastName) {
                        $query->where('first_name', 'like', "%{$firstName}%")
                            ->where('last_name', 'like', "%{$lastName}%");
                    });
                }
            });
        })
        ->get();

        return view('students.teacher', compact('students'));
}

public function seniorHighSearch(Request $request)
{
    $search = trim($request->input('search'));

    $students = Student::where('year_level', 'like', '%SHS%')
        ->when($search, function ($query) use ($search) {
            $query->where(function ($q) use ($search) {
                $q->where('student_number', 'like', "%{$search}%")
                ->orWhere('first_name', 'like', "%{$search}%")
                ->orWhere('last_name', 'like', "%{$search}%");

                if (str_contains($search, ' ')) {
                    $parts = explode(' ', $search, 2);
                    $firstName = $parts[0];
                    $lastName = $parts[1] ?? '';

                    $q->orWhere(function ($query) use ($firstName, $lastName) {
                        $query->where('first_name', 'like', "%{$firstName}%")
                            ->where('last_name', 'like', "%{$lastName}%");
                    });
                }
            });
        })
        ->get();

    return view('students.shs', compact('students'));
}

public function collegesearch(Request $request)
{
    $query = Student::query();

    if ($request->has('search') && $request->search != '') {
        $search = $request->search;

        // Search by student name or student number
        $query->where(function ($query) use ($search) {
            $query->where('last_name', 'like', '%' . $search . '%')
                ->orWhere('first_name', 'like', '%' . $search . '%')
                ->orWhere('student_number', 'like', '%' . $search . '%');
        });
    }

    $students = $query->get(); 

    return view('students.index', compact('students'));
}


}
