<?php if (isset($component)) { $__componentOriginal91fdd17964e43374ae18c674f95cdaa3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal91fdd17964e43374ae18c674f95cdaa3 = $attributes; } ?>
<?php $component = App\View\Components\AdminLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AdminLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
   <?php $__env->slot('header', null, []); ?> 
      <h2 class="font-semibold text-xl text-gray-800 leading-tight">
          <?php echo e(__('Dashboard')); ?>

      </h2>
   <?php $__env->endSlot(); ?>

  <div class="py-12">
      <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
          <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
              <div class="p-6 text-gray-900">
                  <h1 class="text-2xl font-bold mb-4">Senior High School</h1>

                  <!-- Success Message -->
                  <?php if(session()->has('success')): ?>
                      <div class="mb-4 p-4 bg-green-100 text-green-700 border border-green-400 rounded-lg">
                          <?php echo e(session('success')); ?>

                      </div>
                  <?php endif; ?>
                  
                  <form method="GET" action="<?php echo e(route('admin.auth.student.seniorhigh')); ?>" class="mb-4">
                    <div class="flex items-center space-x-4">
                        <input type="text" name="search" placeholder="Search by name, student number" 
                            value="<?php echo e(request('search')); ?>"
                            class="border rounded-lg p-2 w-1/3">
                        <button type="submit" class="bg-blue-500 text-white px-4 py-2 rounded-lg">
                            Search
                        </button>
                        
                        <!-- Sort by section aligned to the right -->
                        <div class="ml-auto flex space-x-4">
                          <!-- Sort by: Section -->
                          <div>
                              <label for="section" class="block text-gray-700 font-medium"></label>
                              <select name="section" id="section" required
                                  class="px-4 py-2 pr-10 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:outline-none">
                                  <option value="" disabled selected>Sort by: Section</option>
                                  <option value="1">1</option>
                                  <option value="2">2</option>
                                  <option value="3">3</option>
                                  <option value="4">4</option>
                                  <option value="5">5</option>
                                  <option value="6">6</option>
                              </select>
                          </div>
                      
                          <!-- Sort by: Courses -->
                          <div>
                              <label for="course" class="block text-gray-700 font-medium"></label>
                              <select name="course" id="course" required
                                  class="px-4 py-2 pr-10 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:outline-none">
                                  <option value="" disabled selected>Sort by: Courses</option>
                                  <option value="BSIT">BSIT</option>
                                  <option value="BSTM">BSTM</option>
                                  <option value="BSCRIM">BSCRIM</option>
                                  <option value="BSED">BSED</option>
                                  <option value="BSPSYC">BSPSYC</option>
                                  <option value="BSCOMENG">BSCOMENG</option>
                              </select>
                          </div>
                      </div>
                      
                    </div>
                </form>
                
                  
                  <!-- Table -->
                  <div class="overflow-y-auto max-h-300 border border-gray-300 rounded-lg shadow-md">
                      <table class="min-w-full bg-white">
                          <thead class="bg-gray-200 text-gray-700 uppercase text-sm leading-normal sticky top-0 z-10">
                              <tr>

                                  <th class="py-3 px-6 text-left">Student Name</th>
                                  <th class="py-3 px-6 text-left">Student Number</th>
                                  <th class="py-3 px-6 text-left">Year Level</th>
                                  <th class="py-3 px-6 text-left">Course</th>
                                  <th class="py-3 px-6 text-left">Role/s</th>
                                  <th class="py-3 px-6 text-center">Edit</th>
                                  <th class="py-3 px-6 text-center">Delete</th>
                              </tr>
                          </thead>
                          <tbody class="text-gray-600 text-sm">
                            <?php if($students->isEmpty()): ?>
                                <tr>
                                    <td colspan="7" class="text-center py-4 text-red-500 font-bold">Student not found</td>
                                </tr>
                            <?php else: ?>
                                <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if(str_contains($student->year_level, 'SHS') && !str_contains($student->roles, 'teacher')): ?>
                                        <?php
                                            $roles = is_array($student->roles) ? implode(',', $student->roles) : $student->roles;
                                            $bgColor = 'bg-white';
                        
                                            if (str_contains($roles, 'admin')) {
                                                $bgColor = 'bg-yellow-200';
                                            } elseif (str_contains($roles, 'student')) {
                                                $bgColor = 'bg-green-200';
                                            } elseif (str_contains($roles, 'kupal')) {
                                                $bgColor = 'bg-red-200';
                                            }
                                        ?>
                        
                                        <tr class="border-b border-gray-300 hover:bg-gray-200 <?php echo e($bgColor); ?>">
                                            <td class="py-3 px-6"><?php echo e($student->last_name); ?> <?php echo e($student->first_name); ?></td>
                                            <td class="py-3 px-6"><?php echo e($student->student_number); ?></td>
                                            <td class="py-3 px-6"><?php echo e($student->year_level); ?></td>
                                            <td class="py-3 px-6"><?php echo e($student->course); ?></td>
                                            <td class="py-3 px-6"><?php echo e($student->roles); ?></td>
                                            <td class="py-3 px-6 text-center">
                                                <a href="<?php echo e(route('student.edit', ['student' => $student])); ?>" 
                                                    class="bg-blue-500 hover:bg-blue-600 text-white py-1 px-3 rounded text-sm">
                                                    Edit
                                                </a>
                                            </td>
                                            <td class="py-3 px-6 text-center">
                                                <form method="post" action="<?php echo e(route('student.destroy', ['student' => $student])); ?>" 
                                                        onsubmit="return confirm('Are you sure you want to delete this student?');">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('delete'); ?>
                                                    <button type="submit" 
                                                            class="bg-red-500 hover:bg-red-600 text-white py-1 px-3 rounded text-sm">
                                                        Delete
                                                    </button>
                                                </form>
                                            </td>
                                        </tr>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </tbody>
                        
                      </table>
                  </div>
                  
              </div>
          </div>
      </div>
  </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal91fdd17964e43374ae18c674f95cdaa3)): ?>
<?php $attributes = $__attributesOriginal91fdd17964e43374ae18c674f95cdaa3; ?>
<?php unset($__attributesOriginal91fdd17964e43374ae18c674f95cdaa3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal91fdd17964e43374ae18c674f95cdaa3)): ?>
<?php $component = $__componentOriginal91fdd17964e43374ae18c674f95cdaa3; ?>
<?php unset($__componentOriginal91fdd17964e43374ae18c674f95cdaa3); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\MIS\resources\views/students/shs.blade.php ENDPATH**/ ?>