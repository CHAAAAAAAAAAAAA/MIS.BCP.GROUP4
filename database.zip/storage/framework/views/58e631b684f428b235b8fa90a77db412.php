<?php if (isset($component)) { $__componentOriginal91fdd17964e43374ae18c674f95cdaa3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal91fdd17964e43374ae18c674f95cdaa3 = $attributes; } ?>
<?php $component = App\View\Components\AdminLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AdminLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Dashboard')); ?>

        </h2>
     <?php $__env->endSlot(); ?>


    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div class="bg-green-200 rounded-xl p-4 flex items-center">
            <div class="bg-blue-100 p-3 rounded-full">
                <svg class="w-6 h-6 text-blue-500" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M17 20h5v-2a3 3 0 00-3-3h-4M4 20h5v-2a3 3 0 00-3-3H4m0 0a3 3 0 003-3V7a3 3 0 00-3-3m0 0a3 3 0 00-3 3v4a3 3 0 003 3m10 6h1a3 3 0 003-3v-4a3 3 0 00-3-3h-1a3 3 0 00-3 3v4a3 3 0 003 3z"></path>
                </svg>
            </div>
            <div class="ml-4 p-4 rounded-lg">
                <h6 class="text-gray-500 text-sm font-semibold">Students</h6>
                <h6 class="text-2xl font-extrabold text-gray-800"><?php echo e($studentCount); ?></h6>
            </div>
        </div>

        <div class="bg-blue-200 rounded-xl p-4 flex items-center">
            <div class="bg-green-100 p-3 rounded-full">
                <svg class="w-6 h-6 text-green-500" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M12 14l9-5-9-5-9 5 9 5zm0 0v7"></path>
                </svg>
            </div>
            <div class="ml-4 p-4 rounded-lg">
                <h6 class="text-gray-500 text-sm font-semibold">Teachers</h6>
                <h6 class="text-2xl font-extrabold text-blue-600"><?php echo e($teacherCount); ?></h6>
            </div>
        </div>

        <div class="bg-yellow-200  rounded-xl p-4 flex items-center">
            <div class="bg-yellow-100 p-3 rounded-full">
                <svg class="w-6 h-6 text-yellow-500" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M12 11c1.657 0 3-.895 3-2s-1.343-2-3-2-3 .895-3 2 1.343 2 3 2zm0 0v8m-4 0h8"></path>
                </svg>
            </div>
            <div class="ml-4 p-4 rounded-lg">
                <h6 class="text-gray-500 text-sm font-semibold">Admin</h6>
                <h6 class="text-2xl font-extrabold text-yellow-600"><?php echo e($adminCount); ?></h6>
            </div>
        </div>

        <div class="bg-red-200 rounded-xl p-4 flex items-center">
            <div class="bg-yellow-100 p-3 rounded-full">
                <svg class="w-6 h-6 text-yellow-500" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M12 11c1.657 0 3-.895 3-2s-1.343-2-3-2-3 .895-3 2 1.343 2 3 2zm0 0v8m-4 0h8"></path>
                </svg>
            </div>
            <div class="ml-4">
                <h6 class="text-gray-500 text-sm font-semibold">All Person</h6>
                <h6 class="text-2xl font-extrabold text-red-600"><?php echo e($allpersonCount); ?></h6>
            </div>
        </div>
    </div>

    <div class="py-12">
        <div class="max-w-4xl mx-auto px-6 lg:px-8">
            <div class="bg-white shadow-lg rounded-lg overflow-hidden">
                <div class="p-6">
                    <h3 class="text-2xl font-bold text-blue-600 mb-4">📢 ANNOUNCEMENT</h3>
                    <h4 class="text-xl font-semibold text-gray-900 mb-3">A Heartfelt Thank You from the MIS Department! 💻🎉</h4>
                    <p class="text-gray-700 leading-relaxed">
                        To the entire <span class="font-semibold">Bestlink College of the Philippines</span> community,<br><br>
                        We extend our sincerest gratitude for your continuous support and trust in the
                        <span class="font-semibold">Management Information System (MIS) Department</span>. Your cooperation and
                        engagement inspire us to enhance our services, ensuring a seamless and efficient digital
                        experience for students, faculty, and staff.
                    </p>
                    <p class="text-gray-700 leading-relaxed mt-4">
                        As we move forward, we remain committed to innovation, security, and excellence in providing
                        reliable IT solutions. Your feedback and collaboration fuel our dedication to improving our systems
                        for a better and smarter campus experience.
                    </p>
                    <p class="text-gray-700 leading-relaxed mt-4">
                        Thank you for being part of this journey! Let’s continue to embrace technology and innovation
                        together. 💙✨
                    </p>
                    <div class="mt-6 p-4 bg-blue-100 border-l-4 border-blue-500 rounded">
                        <p class="text-blue-800 font-medium">
                            📌 For inquiries and assistance, feel free to visit the MIS Office or contact us through our official channels.
                        </p>
                    </div>
                    <div class="mt-6 text-gray-600 font-semibold text-sm">
                        #BestlinkMIS #ThankYouBestlinkers #TechForTheFuture 🚀
                    </div>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal91fdd17964e43374ae18c674f95cdaa3)): ?>
<?php $attributes = $__attributesOriginal91fdd17964e43374ae18c674f95cdaa3; ?>
<?php unset($__attributesOriginal91fdd17964e43374ae18c674f95cdaa3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal91fdd17964e43374ae18c674f95cdaa3)): ?>
<?php $component = $__componentOriginal91fdd17964e43374ae18c674f95cdaa3; ?>
<?php unset($__componentOriginal91fdd17964e43374ae18c674f95cdaa3); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\MIS\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>