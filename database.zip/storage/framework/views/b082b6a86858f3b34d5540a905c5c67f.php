<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

        <title><?php echo e(config('app.name', 'Laravel')); ?></title>

        <!-- Fonts -->
        <link rel="preconnect" href="https://fonts.bunny.net">
        <link href="https://fonts.bunny.net/css?family=figtree:400,500,600&display=swap" rel="stylesheet" />

        <!-- Scripts -->
        <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
    </head>
    <body class="font-sans antialiased">
        <div class="relative min-h-screen flex" x-data="{ open: true }">
            <!-- Sidebar -->
            
<aside 
    :class="open ? 'w-64' : 'w-0 md:w-16'" 
    class="bg-gray-900 text-white transform transition-all duration-300 ease-in-out shadow-lg relative overflow-hidden h-screen fixed top-0 left-0"
>
    <!-- Sidebar Content -->
    <div x-show="open" x-transition.opacity.delay.200ms class="flex flex-col w-64 h-full bg-gray-900 text-white shadow-lg overflow-y-auto">
        <div class="flex items-center justify-between border-b border-gray-700 px-4 py-3">
            <div class="flex items-center space-x-2">
                <a href="#">
                    <?php if (isset($component)) { $__componentOriginal8892e718f3d0d7a916180885c6f012e7 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8892e718f3d0d7a916180885c6f012e7 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.application-logo','data' => ['class' => 'block h-10 w-auto fill-current text-blue-300']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('application-logo'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'block h-10 w-auto fill-current text-blue-300']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8892e718f3d0d7a916180885c6f012e7)): ?>
<?php $attributes = $__attributesOriginal8892e718f3d0d7a916180885c6f012e7; ?>
<?php unset($__attributesOriginal8892e718f3d0d7a916180885c6f012e7); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8892e718f3d0d7a916180885c6f012e7)): ?>
<?php $component = $__componentOriginal8892e718f3d0d7a916180885c6f012e7; ?>
<?php unset($__componentOriginal8892e718f3d0d7a916180885c6f012e7); ?>
<?php endif; ?>
                </a>  
                <span class="text-2xl font-extrabold text-white">Admin</span>
            </div>
            <!-- Close Button -->
            <button @click="open = false" class="p-2 rounded-md text-gray-400 hover:bg-gray-700 focus:outline-none">
                <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
                </svg>
            </button>
        </div>

        
        <nav class="mt-4 space-y-2 px-4 overflow-y-auto flex-grow bg-gray-900 text-white h-screen">
            <!-- Dashboard -->
            <a href="<?php echo e(route('admin.dashboard')); ?>" class="flex items-center space-x-2 px-4 py-3 rounded-lg hover:bg-gray-700 transition">
                <span class="text-xl">🏠</span>
                <span class="font-semibold">Home</span>
            </a>

            <!-- Student Section -->
            
        <hr>

        <div x-data="{ open: false }">
            <!-- Dropdown Button -->
            <h1>Account Information</h1>
            <a @click="open = !open" class="flex items-center justify-between space-x-2 px-4 py-3 rounded-lg hover:bg-gray-700 transition cursor-pointer">
                <div class="flex items-center space-x-2">
                    <span class="text-xl">🎓</span>
                    <span>User Management</span>
                </div>
                <!-- Arrow Indicator -->
                <svg :class="{'rotate-180': open}" class="w-5 h-5 text-gray-400 transition-transform" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M19 9l-7 7-7-7" />
                </svg>
            </a>

            <!-- Dropdown Content (Hidden by Default) -->
            <div x-show="open" x-transition class="pl-8">

                <a href="<?php echo e(route('admin.auth.student.shs')); ?>" class="flex items-center space-x-2 px-4 py-2 rounded-lg hover:bg-gray-700 transition">
                    <span class="text-xl"></span>
                    <span>Senior High School</span>
                </a>

                <a href="<?php echo e(route('admin.auth.student.index')); ?>" class="flex items-center space-x-2 px-4 py-2 rounded-lg hover:bg-gray-700 transition">
                    <span class="text-xl"></span>
                    <span>Collage</span>
                </a>

                <a href="<?php echo e(route('admin.auth.student.create')); ?>" class="flex items-center space-x-2 px-4 py-2 rounded-lg hover:bg-gray-700 transition">
                    <span class="text-xl"></span>
                    <span>Personal Details</span>
                </a>

            </div>
        </div>

        <!-- Teacher Section -->
        <hr>

        <div x-data="{ open: false }">
            <!-- Dropdown Button -->
            <a @click="open = !open" class="flex items-center justify-between space-x-2 px-4 py-3 rounded-lg hover:bg-gray-700 transition cursor-pointer">
                <div class="flex items-center space-x-2">
                    <span class="text-xl">👨‍🏫</span>
                    <span>Teacher</span>
                </div>
                <!-- Arrow Indicator -->
                <svg :class="{'rotate-180': open}" class="w-5 h-5 text-gray-400 transition-transform" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M19 9l-7 7-7-7" />
                </svg>
            </a>

            <!-- Dropdown Content (Hidden by Default) -->
            <div x-show="open" x-transition class="pl-8">

                <a href="<?php echo e(route('admin.auth.student.teacher')); ?>" class="flex items-center space-x-2 px-4 py-2 rounded-lg hover:bg-gray-700 transition">
                    <span class="text-xl"></span>
                    <span>Teacher</span>
                </a>

                <a href="<?php echo e(route('admin.auth.student.createe')); ?>" class="flex items-center space-x-2 px-4 py-2 rounded-lg hover:bg-gray-700 transition">
                    <span class="text-xl"></span>
                    <span>Teacher Create</span>
                </a>

            </div>
        </div>


        <!-- Enrollment Management -->
        <hr>
        <h1>Services</h1>
        <div x-data="{ open: false }">
            <!-- Dropdown Button -->
            <a @click="open = !open" class="flex items-center justify-between space-x-2 px-4 py-3 rounded-lg hover:bg-gray-700 transition cursor-pointer">
                <div class="flex items-center space-x-2">
                    <span class="text-xl">📝</span>
                    <span>Student Concern</span>
                </div>
                <!-- Arrow Indicator -->
                <svg :class="{'rotate-180': open}" class="w-5 h-5 text-gray-400 transition-transform" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M19 9l-7 7-7-7" />
                </svg>
            </a>

            <!-- Dropdown Content (Hidden by Default) -->
            <div x-show="open" x-transition class="pl-8">
                <a href="<?php echo e(route('dashboard')); ?>" class="flex items-center space-x-2 px-4 py-2 rounded-lg hover:bg-gray-700 transition">
                    <span class="text-xl">📝</span>
                    <span>Module</span>
                </a>

                <a href="<?php echo e(route('dashboard')); ?>" class="flex items-center space-x-2 px-4 py-2 rounded-lg hover:bg-gray-700 transition">
                    <span class="text-xl">🎓</span>
                    <span>Module</span>
                </a>
            </div>
        </div>


        <!-- Academic Records< -->
        <hr>
        
        <div x-data="{ open: false }">
            <!-- Dropdown Button -->
            <a @click="open = !open" class="flex items-center justify-between space-x-2 px-4 py-3 rounded-lg hover:bg-gray-700 transition cursor-pointer">
                <div class="flex items-center space-x-2">
                    <span class="text-xl"> 🏅 </span>
                    <span>Academic Records</span>
                </div>
                <!-- Arrow Indicator -->
                <svg :class="{'rotate-180': open}" class="w-5 h-5 text-gray-400 transition-transform" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M19 9l-7 7-7-7" />
                </svg>
            </a>

            <!-- Dropdown Content (Hidden by Default) -->
            <div x-show="open" x-transition class="pl-8">
                <a href="<?php echo e(route('dashboard')); ?>" class="flex items-center space-x-2 px-4 py-2 rounded-lg hover:bg-gray-700 transition">
                    <span class="text-xl">📝</span>
                    <span>Module</span>
                </a>

                <a href="<?php echo e(route('dashboard')); ?>" class="flex items-center space-x-2 px-4 py-2 rounded-lg hover:bg-gray-700 transition">
                    <span class="text-xl">🎓</span>
                    <span>Module</span>
                </a>
            </div>
        </div>

        
        <!-- General Ledger< -->
        <hr>
        
        <div x-data="{ open: false }">
            <!-- Dropdown Button -->
            <a @click="open = !open" class="flex items-center justify-between space-x-2 px-4 py-3 rounded-lg hover:bg-gray-700 transition cursor-pointer">
                <div class="flex items-center space-x-2">
                    <span class="text-xl"> 💰 </span>
                    <span>General Ledger</span>
                </div>
                <!-- Arrow Indicator -->
                <svg :class="{'rotate-180': open}" class="w-5 h-5 text-gray-400 transition-transform" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M19 9l-7 7-7-7" />
                </svg>
            </a>

            <!-- Dropdown Content (Hidden by Default) -->
            <div x-show="open" x-transition class="pl-8">
                <a href="<?php echo e(route('dashboard')); ?>" class="flex items-center space-x-2 px-4 py-2 rounded-lg hover:bg-gray-700 transition">
                    <span class="text-xl">📝</span>
                    <span>Transaction</span>
                </a>

                <a href="<?php echo e(route('dashboard')); ?>" class="flex items-center space-x-2 px-4 py-2 rounded-lg hover:bg-gray-700 transition">
                    <span class="text-xl">🎓</span>
                    <span>Balance Update</span>
                </a>
            </div>
        </div>



        </nav>

    </div>
</aside>



        
            <!-- Main Content -->
            <div class="flex-1 transition-all duration-300">
                <nav class="bg-blue-900 shadow-lg">
                    <div class="mx-auto px-2 sm:px-6 lg:px-8">
                        <div class="relative flex items-center justify-between md:justify-end h-16">
                            <div class="absolute inset-y-0 left-0 flex items-center">

                                <!-- Sidebar Toggle Button -->
                                <button @click="open = !open" class="p-2 rounded-md text-blue-100 hover:bg-blue-700 focus:outline-none">
                                    <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor">
                                        <path stroke-linecap="round" stroke-linejoin="round" d="M3.75 6.75h16.5M3.75 12h16.5m-16.5 5.25h16.5" />
                                    </svg>
                                </button>
                            </div>
                            <div class="absolute inset-y-0 right-0 flex items-center">
                                <?php if (isset($component)) { $__componentOriginaldf8083d4a852c446488d8d384bbc7cbe = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldf8083d4a852c446488d8d384bbc7cbe = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dropdown','data' => ['align' => 'right','width' => '48']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('dropdown'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['align' => 'right','width' => '48']); ?>
                                     <?php $__env->slot('trigger', null, []); ?> 
                                        <button class="inline-flex items-center px-3 py-2 border border-transparent text-sm leading-4 font-medium text-blue-100 hover:bg-blue-700 focus:outline-none transition ease-in-out duration-200 p-2 rounded-md">
                                            
                
                                            <div class="ms-1">
                                                <svg class="fill-current h-4 w-4" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20">
                                                    <path fill-rule="evenodd" d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clip-rule="evenodd" />
                                                </svg>
                                            </div>
                                        </button>
                                     <?php $__env->endSlot(); ?>
                
                                     <?php $__env->slot('content', null, []); ?> 
                                        <?php if (isset($component)) { $__componentOriginal68cb1971a2b92c9735f83359058f7108 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal68cb1971a2b92c9735f83359058f7108 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dropdown-link','data' => ['href' => route('profile.edit')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('dropdown-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('profile.edit'))]); ?>
                                            <?php echo e(__('Profile')); ?>

                                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal68cb1971a2b92c9735f83359058f7108)): ?>
<?php $attributes = $__attributesOriginal68cb1971a2b92c9735f83359058f7108; ?>
<?php unset($__attributesOriginal68cb1971a2b92c9735f83359058f7108); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal68cb1971a2b92c9735f83359058f7108)): ?>
<?php $component = $__componentOriginal68cb1971a2b92c9735f83359058f7108; ?>
<?php unset($__componentOriginal68cb1971a2b92c9735f83359058f7108); ?>
<?php endif; ?>
                
                                        <!-- Authentication -->
                                        <form method="POST" action="<?php echo e(route('admin.logout')); ?>">
                                        <?php echo csrf_field(); ?>
                                            <button type="submit">Logout</button>
                                        </form>

                                     <?php $__env->endSlot(); ?>
                                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldf8083d4a852c446488d8d384bbc7cbe)): ?>
<?php $attributes = $__attributesOriginaldf8083d4a852c446488d8d384bbc7cbe; ?>
<?php unset($__attributesOriginaldf8083d4a852c446488d8d384bbc7cbe); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldf8083d4a852c446488d8d384bbc7cbe)): ?>
<?php $component = $__componentOriginaldf8083d4a852c446488d8d384bbc7cbe; ?>
<?php unset($__componentOriginaldf8083d4a852c446488d8d384bbc7cbe); ?>
<?php endif; ?>
                            </div>
                        </div>
                        
                    </div>
                </nav>
                <div>
                    <?php echo e($slot); ?>

                </div>
            </div>
        </div>
        
        
        

    </body>
</html>
<?php /**PATH C:\xampp\htdocs\MIS\resources\views/layouts/admin.blade.php ENDPATH**/ ?>