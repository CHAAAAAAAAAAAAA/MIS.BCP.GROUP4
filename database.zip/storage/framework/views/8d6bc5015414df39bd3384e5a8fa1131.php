<?php if (isset($component)) { $__componentOriginal91fdd17964e43374ae18c674f95cdaa3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal91fdd17964e43374ae18c674f95cdaa3 = $attributes; } ?>
<?php $component = App\View\Components\AdminLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AdminLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
   <?php $__env->slot('header', null, []); ?> 
      <h2 class="font-semibold text-xl text-gray-800 leading-tight">
          <?php echo e(__('Edit Student')); ?>

      </h2>
   <?php $__env->endSlot(); ?>

  <div class="py-12">
      <div class="max-w-4xl mx-auto sm:px-6 lg:px-8">
          <div class="bg-white shadow-md rounded-lg p-6">
              <h1 class="text-2xl font-bold text-gray-800 mb-4">Edit Teacher</h1>

              <!-- Success Message -->
              <?php if(session()->has('success')): ?>
                  <div class="mb-4 p-4 bg-green-100 text-green-700 border border-green-400 rounded-lg">
                      <?php echo e(session('success')); ?>

                  </div>
              <?php endif; ?>

              <!-- Error Messages -->
              <?php if($errors->any()): ?>
                  <div class="mb-4 p-4 bg-red-100 text-red-700 border border-red-400 rounded-lg">
                      <ul>
                          <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <li><?php echo e($error); ?></li>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </ul>
                  </div>
              <?php endif; ?>

              <!-- Form -->
              <form method="post" action="<?php echo e(route('student.update', ['student' => $student])); ?>" class="space-y-4">
                  <?php echo csrf_field(); ?>
                  <?php echo method_field('put'); ?>

                  <div>
                      <label class="block text-gray-700 font-medium">Student Number</label>
                      <input type="text" name="student_number" value="<?php echo e($student->student_number); ?>" 
                              class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:outline-none">
                  </div>

                  <div>
                      <label class="block text-gray-700 font-medium">Last Name</label>
                      <input type="text" name="last_name" value="<?php echo e($student->last_name); ?>" 
                              class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:outline-none">
                  </div>

                  <div>
                      <label class="block text-gray-700 font-medium">First Name</label>
                      <input type="text" name="first_name" value="<?php echo e($student->first_name); ?>" 
                              class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:outline-none">
                  </div>

                  <div>
                      <label class="block text-gray-700 font-medium">Email</label>
                      <input type="text" name="email" placeholder="Email" required
                          class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:outline-none">
                  </div>

                  <label for="roles" class="block text-gray-700 font-medium">Role</label>
                  <select name="roles" id="roles"
                      class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:outline-none">
                      <option value="" disabled selected>Select your role</option>

                      <option value="teacher">teacher</option>
                  </select>
                  </div>

                  <div>
                      <button type="submit"
                          class="w-full bg-blue-500 hover:bg-blue-600 text-white font-medium py-2 px-4 rounded-lg transition duration-200">
                          Update Student
                      </button>
                  </div>
              </form>
          </div>
      </div>
  </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal91fdd17964e43374ae18c674f95cdaa3)): ?>
<?php $attributes = $__attributesOriginal91fdd17964e43374ae18c674f95cdaa3; ?>
<?php unset($__attributesOriginal91fdd17964e43374ae18c674f95cdaa3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal91fdd17964e43374ae18c674f95cdaa3)): ?>
<?php $component = $__componentOriginal91fdd17964e43374ae18c674f95cdaa3; ?>
<?php unset($__componentOriginal91fdd17964e43374ae18c674f95cdaa3); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\MIS\resources\views/students/teacheredit.blade.php ENDPATH**/ ?>