<?php

use App\Http\Controllers\ProfileController;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\StudentController;

use App\Http\Controllers\DashboardController;

Route::get('/', function () {
    return redirect('login');
});

Route::get('/userdashboard', function () {
    return view('userdashboard');
})->name('userdashboard');


Route::get('/student', [StudentController::class, 'index'])->name('student.index');
Route::get('/student/create', [StudentController::class, 'create'])->name('student.create');
Route::get('/student/createe', [StudentController::class, 'createe'])->name('student.createe');
Route::post('/student', [StudentController::class, 'store'])->name('student.store');
Route::post('/student/teacher', [StudentController::class, 'teacherstore'])->name('teacher.store');
Route::get('/student/{student}/edit', [StudentController::class, 'edit'])->name('student.edit');

Route::get('/student/teacher/{student}/edit', [StudentController::class, 'editTeacher'])->name('student.teacheredit');
Route::get('/admin/auth/student/teacher', [StudentController::class, 'teachersearch'])
    ->name('admin.auth.student.teacher');

Route::get('/admin/auth/student/teacher', [StudentController::class, 'teachersearch'])
    ->name('admin.auth.student.teacher');

Route::get('/admin/auth/student/seniorhigh', [StudentController::class, 'seniorHighSearch'])
    ->name('admin.auth.student.seniorhigh');

Route::get('/admin/auth/student/college', [StudentController::class, 'collegesearch'])
    ->name('admin.auth.student.college');



Route::put('/student/{student}/update', [StudentController::class, 'update'])->name('student.update');
Route::delete('/student/{student}/destroy', [StudentController::class, 'destroy'])->name('student.destroy');
Route::get('/dashboard', [StudentController::class, 'scount'])->name('dashboard');


Route::prefix('admin')->name('admin.')->group(function () {
    Route::get('/create-teacher', [StudentController::class, 'createTeacher'])->name('createTeacher');
});


Route::get('/admin/auth/student/shs', [StudentController::class, 'indexSHS'])->name('admin.auth.student.shs');

Route::get('/admin/auth/student/teacher', [StudentController::class, 'teacher'])->name('admin.auth.student.teacher');

Route::get('/students/college', [StudentController::class, 'indexCollege'])->name('students.college');

Route::get('/students/senior-high', [StudentController::class, 'indexSeniorHigh'])->name('students.senior_high');





Route::get('/Module 1', function () {
    return view('dashboard');
})->middleware(['auth', 'verified'])->name('Module 1');

Route::get('/Module 2', function () {
    return view('dashboard');
})->middleware(['auth', 'verified'])->name('Module 2');

Route::get('/Module 3', function () {
    return view('dashboard');
})->middleware(['auth', 'verified'])->name('Module 3');

Route::middleware('auth')->group(function () {
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');
});

require __DIR__.'/auth.php';

require __DIR__.'/admin-auth.php';
