<x-user-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            {{ __('Dashboard') }}
        </h2>
    </x-slot>



    <div class="py-12">
        <div class="max-w-4xl mx-auto px-6 lg:px-8">
            <div class="bg-white shadow-lg rounded-lg overflow-hidden">
                <div class="p-6">
                    <h3 class="text-2xl font-bold text-blue-600 mb-4">📢 ANNOUNCEMENT</h3>
                    <h4 class="text-xl font-semibold text-gray-900 mb-3">A Heartfelt Thank You from the MIS Department! 💻🎉</h4>
                    <p class="text-gray-700 leading-relaxed">
                        To the entire <span class="font-semibold">Bestlink College of the Philippines</span> community,<br><br>
                        We extend our sincerest gratitude for your continuous support and trust in the
                        <span class="font-semibold">Management Information System (MIS) Department</span>. Your cooperation and
                        engagement inspire us to enhance our services, ensuring a seamless and efficient digital
                        experience for students, faculty, and staff.
                    </p>
                    <p class="text-gray-700 leading-relaxed mt-4">
                        As we move forward, we remain committed to innovation, security, and excellence in providing
                        reliable IT solutions. Your feedback and collaboration fuel our dedication to improving our systems
                        for a better and smarter campus experience.
                    </p>
                    <p class="text-gray-700 leading-relaxed mt-4">
                        Thank you for being part of this journey! Let’s continue to embrace technology and innovation
                        together. 💙✨
                    </p>
                    <div class="mt-6 p-4 bg-blue-100 border-l-4 border-blue-500 rounded">
                        <p class="text-blue-800 font-medium">
                            📌 For inquiries and assistance, feel free to visit the MIS Office or contact us through our official channels.
                        </p>
                    </div>
                    <div class="mt-6 text-gray-600 font-semibold text-sm">
                        #BestlinkMIS #ThankYouBestlinkers #TechForTheFuture 🚀
                    </div>
                </div>
            </div>
        </div>
    </div>
</x-user-layout>
