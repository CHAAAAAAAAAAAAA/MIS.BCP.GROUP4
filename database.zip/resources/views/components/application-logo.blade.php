<img src="{{ asset('logo/bcp.png') }}" alt="Application Logo" {{ $attributes->merge(['class' => 'w-20 h-20']) }}>
